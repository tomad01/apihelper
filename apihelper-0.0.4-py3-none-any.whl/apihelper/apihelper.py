from timeit import default_timer as timer
from datetime import datetime
import time,sys,traceback

def ChTimeForm(time_str,_from,_to):
    return datetime.strftime(datetime.strptime(time_str,_from),_to)[:-3]

def pretty_time(sec):
    if sec/3600>=1:
        time = sec/3600.0;unit = '[h]'
    elif sec/60>=1:
        time = sec/60.0;unit = '[min]'
    elif sec/60<1:
        time = sec;unit = '[sec]'
    return '%.2f %s'%(time,unit)

class Timer(object):
    def __init__(self, arg=1):
        self.arg = arg
    def __call__(self,f):        
        def inner(*args, **kwargs):
            start = timer()
            f(*args, **kwargs)            
            print('elapsed %s'%pretty_time(timer() - start))
        return inner
    
class Logger_traceback(object):
    def __init__(self,mode,filename="Default.log"):
        self.terminal = sys.stdout
        self.log = open(filename,mode)
    def write(self, message):
        traceback.print_exc(file=self.log)
        self.terminal.write(message)
        self.log.write(message)        
    def flush(self):
        self.log.flush()

class Log_traceback(object):
    def __init__(self, mode="a",filename="Default.log"):
        self.mode = mode
        self.arg = filename
    def __call__(self,f):        
        def inner(*args, **kwargs):
            orig_stdout = sys.stdout
            orig_stderr = sys.stderr
            sys.stdout = Logger_traceback(self.mode,self.arg)
            sys.stderr = Logger_traceback(self.mode,self.arg)
            f(*args, **kwargs)
            sys.stdout = orig_stdout
            sys.stderr = orig_stderr                                     
        return inner
    
class Logger(object):
    def __init__(self,mode,filename="Default.log"):
        self.terminal = sys.stdout
        self.log = open(filename,mode)
    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)
        self.log.flush()
    def flush(self):
        pass
    
class Log(object):
    def __init__(self, mode="a",filename="Default.log"):
        self.mode = mode
        self.arg = filename
    def __call__(self,f):        
        def inner(*args, **kwargs):
            orig_stdout = sys.stdout
            orig_stderr = sys.stderr
            sys.stdout = Logger(self.mode,self.arg)
            sys.stderr = Logger(self.mode,self.arg)
            f(*args, **kwargs)
            sys.stdout = orig_stdout
            sys.stderr = orig_stderr                                     
        return inner
            
class Wait_bar(object):
    def __init__(self,iterations = 0,often=1,increment =1):
        self.laps = []
        self.cnt = 0
        self.ref = timer()
        self.iter = iterations
        self.incr = increment
        self.global_ref = timer()
        self.often = often
    def display(self):
        self.cnt+=self.incr
        if self.cnt%self.often==0:
            est_left_time = (self.iter - self.cnt)*(timer()-self.ref)/float(self.often)
            passed = pretty_time(timer()-self.global_ref)
            print('%.2f%% done, estimated left time: %s, passed: %s'%((100*self.cnt)/float(self.iter),pretty_time(est_left_time),passed))
            self.laps.append((timer(),est_left_time))
            self.ref = timer()

class Retry(object):
    def __init__(self, sleep=0.5,iters=2, exception = Exception):
        self.max = iters
        self.excep = exception
        self.pause = sleep
    def __call__(self,f):        
        def inner(*args, **kwargs):
            cnt=0
            while True:
                if cnt>self.max:                    
                    raise Exception('maximum execution times reached')
                if cnt>0:
                    print('error %s occured, sleeping %d [sec]...'%(str(self.excep),self.pause))
                    time.sleep(self.pause)
                try:             
                    f(*args, **kwargs)
                except self.excep:
                    cnt+=1
                    continue
                break
        return inner
